import{Y as e,_ as n}from"../chunks/2.CUUBckXJ.js";export{e as component,n as universal};
//# sourceMappingURL=2.BvEqVKbk.js.map
