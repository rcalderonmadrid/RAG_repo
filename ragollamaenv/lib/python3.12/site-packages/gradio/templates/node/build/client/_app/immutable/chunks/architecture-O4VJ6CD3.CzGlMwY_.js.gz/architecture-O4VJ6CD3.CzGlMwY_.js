import{A as c,e as t}from"./mermaid-parser.core.BQLuD0QL.js";export{c as ArchitectureModule,t as createArchitectureServices};
//# sourceMappingURL=architecture-O4VJ6CD3.CzGlMwY_.js.map
