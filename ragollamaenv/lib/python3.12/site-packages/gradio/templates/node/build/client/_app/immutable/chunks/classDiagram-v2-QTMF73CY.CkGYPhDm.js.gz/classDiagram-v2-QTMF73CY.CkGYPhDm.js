import{c as r,C as s,a as e,s as t}from"./chunk-JBRWN2VN.C0R78Ld9.js";import{_ as l}from"./mermaid.core.yM0mWuwh.js";var d={parser:r,get db(){return new s},renderer:e,styles:t,init:l(a=>{a.class||(a.class={}),a.class.arrowMarkerAbsolute=a.arrowMarkerAbsolute},"init")};export{d as diagram};
//# sourceMappingURL=classDiagram-v2-QTMF73CY.CkGYPhDm.js.map
