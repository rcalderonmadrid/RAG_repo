import{s as t}from"../chunks/client.b14aJMjB.js";export{t as start};
//# sourceMappingURL=start.BwRSP6kU.js.map
