import{I as r,c as a}from"./mermaid-parser.core.BQLuD0QL.js";export{r as InfoModule,a as createInfoServices};
//# sourceMappingURL=info-63CPKGFF.xeWmdaEM.js.map
