import{r}from"./2.CUUBckXJ.js";const t=o=>r[o%r.length];export{t as g};
//# sourceMappingURL=color.D3BoDPe9.js.map
