import{P as c,a as r}from"./mermaid-parser.core.BQLuD0QL.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-HUATNLJX.CWO95g-c.js.map
